/*
 * Copyright (C) 2022 IUT
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package saegraphemap;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import saegraphemap.types.Lien;
import saegraphemap.types.Noeud;

/**
 * Cette classe représente la transformation des données du csv en plusieurs objets de type Noeud et Lien
 * @author Noé CHOUTEAU
 */

public class csvTraducteur {

    
    
 // <editor-fold defaultstate="collapsed" desc="    ATTRIBUTS">
    /**
     * Correspond à la liste des noeuds lorsqu'ils sont encore de type String
     */
    private ArrayList<String> listeNoeuds = new ArrayList<>();
    
    /**
     * Correspond à la liste des noeud une fois leurs informations bien passées dans le constructeur du type Noeud
     */
    private ArrayList<Noeud> listeNoeudsDistinct = new ArrayList<>();
    
    /**
     * Correspond à la liste des liens lorsqu'ils sont encore de type String et qu'il sont plusieurs par string
     */
    private ArrayList<String> listeLiens = new ArrayList<>();
    
    /**
     * Correspond à la liste des liens lorsqu'ils sont encore de type String mais uniquement un lien par String
     */
    private ArrayList<String> listeLiensUniques = new ArrayList<>();
    
    /**
     * Correspond à la liste des liens une fois leurs informations bien passées dans le constructeur du type Lien et sans les doublons
     */
    private ArrayList<Lien> listeLiensDistinct = new ArrayList<>();
 
    /**
     * Correspond au chemin courant du fichier
     */
    private File  cheminCourant;
    
     // </editor-fold>
    
    
// <editor-fold defaultstate="collapsed" desc="    METHODES PUBLICS">
   /**
     * Sélectionne un fichier csv pour le transformer en enemble d'objets Noeud et Lien
     */
    public void creationNoeudsLiens() throws FileNotFoundException{
        
                //Création de notre JFileChooser pour permettre à l'utilisateur de sélectionner son fichier
                JFileChooser ouvrir = new JFileChooser();
                 ouvrir.addChoosableFileFilter(new FileNameExtensionFilter("Fichier TXT (*.txt)", "txt"));
                 ouvrir.setApproveButtonText("Ouvrir");
                 ouvrir.setDialogTitle("Ouvrir");
                 ouvrir.setDialogType(JFileChooser.OPEN_DIALOG);
                 ouvrir.setFileSelectionMode(JFileChooser.FILES_ONLY);
                 ouvrir.setMultiSelectionEnabled(false);
                 int result = ouvrir.showOpenDialog(null);
                 if(result == JFileChooser.APPROVE_OPTION){
                     try
                      {
                            cheminCourant = ouvrir.getSelectedFile();
                      }

                     catch(Exception exception)
                     {
                      //Print Error in file processing if it can't process your text file
                      System.out.println("Error in file processing");
                      JOptionPane.showConfirmDialog(null,"Le fichier n'existe pas.", "Fichier introuvable", JOptionPane.OK_OPTION, JOptionPane.WARNING_MESSAGE);
                     }
                 } else if(result == JFileChooser.CANCEL_OPTION);
        
        //création des readers et scans pour pouvoir lire le fichier et modifier ce qu'on récupère
        FileReader fichierChoisi = new  FileReader(cheminCourant);
        
        Scanner fileReaderScan=new Scanner(fichierChoisi);
        String texteEntier="";
        
       while(fileReaderScan.hasNextLine())
                           {
                            String temp=fileReaderScan.nextLine()+"\n";

                            texteEntier=texteEntier+temp;
                           };
                           
            //On commence par identifier ce qui sépare nos lignes
            String[] line = texteEntier.split(";;");
            for(String line2 : line){
                
                //Puis, pour chaque ligne, on séparera en deux parties pour obtenir le noeud et ses liens (là où on trouvera ":")
                if(line2.contains(":")){
                        String partieGauche = line2.substring(0, line2.indexOf(":")); //le noeud
                        String partieDroite = line2.substring(line2.indexOf(":")+1, line2.length());// ses liens
                        listeNoeuds.add(partieGauche);
                        
                        //ajout de caractères arbitraires pour déclarer la fin du noeud
                        listeLiens.add(partieDroite + "  " + "&%#");
                }
            }

            //Pour chaque partie de droite contenant plusieurs liens, on va séprarer grâce au ";" en plusieurs liens uniques
            for(int i = 0; i<listeLiens.size();i++){
             String[] separateur = listeLiens.get(i).split(";");
              listeLiensUniques.addAll(Arrays.asList(separateur));
            }

            //Pour chaque noeud, on va séparer le nom du type grâce, encore une fois, à indexOf et le symbole ","
            for(String line2 : listeNoeuds){
                    if(line2.contains(",")){
                            String partieGauche = line2.substring(0, line2.indexOf(","));
                            String partieDroite = line2.substring(line2.indexOf(",")+1, line2.length());
                    if(partieGauche.contains("V")){
                            partieGauche = "V";
                    }
                    else if(partieGauche.contains("L")) {
                            partieGauche = "L";
                    }
                    else {
                            partieGauche = "R";
                    };
                    
                    //création d'un noeud temporaire puis ajout du noeud dans la liste de noeuds finale
                    Noeud noeudTemp = new Noeud(partieGauche,partieDroite, new ArrayList<Lien> ());
                    listeNoeudsDistinct.add(noeudTemp);
                    }
            }                 

            // on crée deux listes: une pour le type et la longueur, l'autre pour le noeud
           ArrayList<String> listeLiensPartieGauche = new ArrayList<>();
           ArrayList<String> listeLiensPartieDroite = new ArrayList<>();
           
           //grâce à indexOf et le symble "::", on obtiendra deux listes comportants des éléments composants un seul et même lien à chaque fois
            for(String line2  : listeLiensUniques){
                if(line2.contains("::")){
                        String partieGauche = line2.substring(0, line2.indexOf("::"));
                        String partieDroite = line2.substring(line2.indexOf("::")+2, line2.length());
                        String[] partieGaucheSepar = partieGauche.split(",");
                        String[] partieDroiteSepar = partieDroite.split(",");
                       listeLiensPartieGauche.addAll(Arrays.asList(partieGaucheSepar));
                       listeLiensPartieDroite.addAll(Arrays.asList(partieDroiteSepar));
                }
            }
            
        int cptNoeud = 0;
            
            for (int i=0; i<listeLiensUniques.size()*2;i++){
                        boolean finDuNoeud = false;
                        int trouveNoeudEnfant = 0;
                         
                        //Pour chaque lien dans la liste des liens uniques, on va attribuer l'autre noeud qui n'est pas renseigné fans la ligne; En effet, notre type de string actuel est "X,00::X,Noeud1". Il faut donc trouver le noeud 2.
                        for(int j = 0; j<listeNoeudsDistinct.size();j++){

                                 //vérifie que le caractère arbitraire est présent pour la fin du noeud
                                 if(listeLiensPartieDroite.get(i+1).contains("&%#")){
                                      finDuNoeud = true;

                                      //On récupère l'emplacement du noeud dans la liste distincte pour pouvoir l'atribuer lors de la création du lien (utilisation de substring car à chauqe fin de ligne se rajoutait des espaces ou des guillemets
                                      if (listeNoeudsDistinct.get(j).getNomNoeud().substring(1, listeNoeudsDistinct.get(j).getNomNoeud().length()).equals(listeLiensPartieDroite.get(i+1).substring(0,listeLiensPartieDroite.get(i+1).indexOf(" ")))){
                                          trouveNoeudEnfant = j;
                                      }
                                 }
                                        
                                    //Si il n'y a pas de uillemets qui poluent, on doit juste retirer les espaces
                                 else  if (listeNoeudsDistinct.get(j).getNomNoeud().substring(1, listeNoeudsDistinct.get(j).getNomNoeud().length()).equals(listeLiensPartieDroite.get(i+1))){
                                          trouveNoeudEnfant = j;
                                      }
                         }

                        //On crée ainsi 2 liens: un lien normal et un lien inverse dont les noeuds parent et enfant sont inversés
                         Lien lienInverse = new Lien(listeLiensPartieGauche.get(i),Integer.parseInt(listeLiensPartieGauche.get(i+1)),listeNoeudsDistinct.get(cptNoeud),listeNoeudsDistinct.get(trouveNoeudEnfant));
                         Lien lien = new Lien(listeLiensPartieGauche.get(i),Integer.parseInt(listeLiensPartieGauche.get(i+1)),listeNoeudsDistinct.get(trouveNoeudEnfant),listeNoeudsDistinct.get(cptNoeud));


                         boolean contient = false;
                         
                         //si la listedistincte contient deja le lien inverse, alors on ajoutera pas le lien normal
                         for(int j = 0; j<listeLiensDistinct.size();j++){
                                if(listeLiensDistinct.get(j).getTypeLien().equals(lienInverse.getTypeLien()) && 
                                       listeLiensDistinct.get(j).getTailleLien() == (lienInverse.getTailleLien()) &&
                                       listeLiensDistinct.get(j).getNoeudParent().equals(lienInverse.getNoeudParent()) &&
                                       listeLiensDistinct.get(j).getNoeudEnfant().equals(lienInverse.getNoeudEnfant())
                                      ){
                                   contient = true;
                         }}
                        if(contient == false && !lien.getNoeudParent().getNomNoeud().equals(" Genève") &&  !lien.getNoeudEnfant().getNomNoeud().equals(" Orléans")){
                        listeLiensDistinct.add(lien);
                        }

                         if( finDuNoeud == true){
                             cptNoeud++;
                         }
                         i++;
            }

            
            //Affichage des liens et des noeuds
            for(int i = 0; i<listeLiensDistinct.size();i++){
                   System.out.println("\n" + listeLiensDistinct.get(i).getTypeLien()+ " " + listeLiensDistinct.get(i).getTailleLien()+ " " + listeLiensDistinct.get(i).getNoeudParent().getNomNoeud()+ " " + listeLiensDistinct.get(i).getNoeudEnfant().getNomNoeud());
                   listeLiensDistinct.get(i).getNoeudParent().addLiens(listeLiensDistinct.get(i));
                   listeLiensDistinct.get(i).getNoeudEnfant().addLiens(listeLiensDistinct.get(i));
            }

             for(int i = 0; i<listeNoeudsDistinct.size();i++){
            System.out.println("\n"+listeNoeudsDistinct.get(i).getTypeNoeud()+ " " + listeNoeudsDistinct.get(i).getNomNoeud() + " " );
                        for(int j = 0; j< listeNoeudsDistinct.get(i).getLiens().size();j++){
                                 System.out.println(listeNoeudsDistinct.get(i).getLiens().get(j).afficheLien());
                        }
            }
             
             System.out.println("Graphe bien chargé dans les types !");
             
    }

   /**
     * Renvoie la liste d'objets de types Noeud sans doublons
     * @return Retourne la liste d'objets de types Noeud sans doublons
     */
    public ArrayList<Noeud> getListeNoeudsDistinct() {
        return listeNoeudsDistinct;
    }
    
   /**
     * Renvoie la liste d'objets de types Liens sans doublons
     * @return Retourne la liste d'objets de types Liens sans doublons
     */
    public ArrayList<Lien> getListeLiensDistinct() {
        return listeLiensDistinct;
    }
// </editor-fold>
    
    
    
}


