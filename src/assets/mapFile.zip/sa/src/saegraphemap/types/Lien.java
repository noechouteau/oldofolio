/*
 * Copyright (C) 2022 IUT
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package saegraphemap.types;

import saegraphemap.types.Noeud;

/**
 * Cette classe représente le type le modèle d'un Lien après avoir transformé le csv en noeuds et liens
 * @author Noé CHOUTEAU
 * @version 1.0
 */
public class Lien {
    
    
    
// <editor-fold defaultstate="collapsed" desc="    ATTRIBUTS">
    /**
     *  Correspond au type de lien, soit " A" pour autoroute, " N" pour nationale et " D" pour départementale
     */
    private String typeLien;
    
    /**
     *  Correspond à la taille (km) de la route théorique entre deux noeuds
     */
    private int tailleLien;
    
    /**
     *  Correspond au premier noeud du lien
     */
    private Noeud noeudParent;
    
    /**
     *  Correspond au deuxième noeud du lien
     */
    private Noeud noeudEnfant;
// </editor-fold>
    
    
    
// <editor-fold defaultstate="collapsed" desc="    CONSTRUCTOR">
    /**
     * Crée un lien que l'on pourra afficher et/ou modifier
     * @param  Correspond au type de lien, soit " A" pour autoroute, " N" pour nationale et " D" pour départementale
     * @param tailleLien Correspond à la taille (km) de la route théorique entre deux noeuds
     * @param noeudParent Correspond au premier noeud du lien
     * @param noeudEnfant Correspond au deuxième noeud du lien
     */
    public Lien(String typeLien, int tailleLien, Noeud noeudParent ,Noeud noeudEnfant) {
        this.typeLien = typeLien;
        this.tailleLien = tailleLien;
        this.noeudParent = noeudParent;
        this.noeudEnfant = noeudEnfant;  
    }
// </editor-fold>
    
    
    
// <editor-fold defaultstate="collapsed" desc="    METHODES PUBLICS">
    /**
     * Renvoie le type du lien sélectionné
     * @return Retourne le type du lien sélectionné
     */
    public String getTypeLien() {
        return typeLien;
    }

    /**
     * Renvoie la taille du lien sélectionné
     * @return Retourne la taille du lien sélectionné
     */
    public int getTailleLien() {
        return tailleLien;
    }

    /**
     * Renvoie le premier noeud du lien sélectionné
     * @return Retourne le premier noeud du lien sélectionné
     */
    public Noeud getNoeudEnfant() {
        return noeudEnfant;
    }

    /**
     * Renvoie le deuxième noeud du lien sélectionné
     * @return Retourne le deuxième noeud du lien sélectionné
     */
    public Noeud getNoeudParent() {
        return noeudParent;
    }

    /**
     * Renvoie les informations les plus importantes pour pouvoir les afficher plus rapidement (juste besoin d'appeler la méthode)
     * @return Retourne le type et le nom du noeud séparés d'une virgule
     */
   public String afficheLien(){
       return(this.getTypeLien() + " " + this.getTailleLien() + " "+ this.getNoeudEnfant().getTypeNoeud() + " "+ this.getNoeudEnfant().getNomNoeud()+ "            " + this.getNoeudParent().getTypeNoeud() + " " + this.getNoeudParent().getNomNoeud());
   }
// </editor-fold>
   
   
   
}
