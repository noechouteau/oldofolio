/*
 * Copyright (C) 2022 IUT
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package saegraphemap;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Cette classe représente les actions à effectuer pour pouvoir sélectionner un noeud.
 * @author Noé CHOUTEAU
 */
public class selectionNoeuds extends MouseAdapter{
    
// <editor-fold defaultstate="collapsed" desc="    METHODE PUBLIC">
    /**
     * En fonction du click et de l'endroit où il est effectué, on doit pouvoir récupérer la position du noeud
     * @param e correspond à l'évènement reçu
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        
        //On vérifie que les noeuds soient visibles
        if(dessinGraphe.getNoeudsVisibles() == true){
            
            //Puis, si le click est un click gauche
            if(e.getButton() == MouseEvent.BUTTON1){
                
            //On récupère les coordonnées du click
            int x = e.getX();
            int y = e.getY();
            dessinGraphe pageDessin = SaeGRAPHEMAP.getPageDessin();
            
            //Pour chaque noeud, si l'endroit cliqué est compris dans une intervalle de 50 pixels autour des coordonées du point(pour pouvoir cliquer sur le rond) alors l'endroit cliqué correspond au noeud que l'on veut sélectionner
            for (int i = 0; i < pageDessin.getListeNoeuds().size(); i++) {
                if (x >= pageDessin.getListeNoeuds().get(i).getCoordX() - 50 && x <= pageDessin.getListeNoeuds().get(i).getCoordX() + 50
                        && y >= pageDessin.getListeNoeuds().get(i).getCoordY() - 30 && y <= pageDessin.getListeNoeuds().get(i).getCoordY() + 50) {
                    SaeGRAPHEMAP.setNoeudSelect(pageDessin.getListeNoeuds().get(i));
                }
            }
            }

            //SI le click estd roit, ce sera le deuxième noeud sélectionné qu'on modifiera
            else if(e.getButton() == MouseEvent.BUTTON3){
            int x = e.getX();
            int y = e.getY();
            dessinGraphe pageDessin = SaeGRAPHEMAP.getPageDessin();
            
            //On réutilise la même formule
            for (int i = 0; i < pageDessin.getListeNoeuds().size(); i++) {
                if (x >= pageDessin.getListeNoeuds().get(i).getCoordX() - 50 && x <= pageDessin.getListeNoeuds().get(i).getCoordX() + 50
                        && y >= pageDessin.getListeNoeuds().get(i).getCoordY() - 30 && y <= pageDessin.getListeNoeuds().get(i).getCoordY() + 50) {
                    SaeGRAPHEMAP.setNoeudSelect2(pageDessin.getListeNoeuds().get(i));
                }
            }
            }
    }
    }
// </editor-fold>
    
}
